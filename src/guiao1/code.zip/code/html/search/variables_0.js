var searchData=
[
  ['mystack_24',['mystack',['../stack_8c.html#aae2740822e2c94e7aeb4314eb76e125a',1,'stack.c']]]
];
