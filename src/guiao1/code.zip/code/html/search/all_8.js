var searchData=
[
  ['_7estack_19',['~Stack',['../classStack.html#a8a2147cf8c3c813b85a3e49b01c3fb09',1,'Stack']]]
];
