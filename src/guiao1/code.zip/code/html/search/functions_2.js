var searchData=
[
  ['stack_5fsize_23',['STACK_SIZE',['../stack_8c.html#af47e5cb287f1c5734a65d00b47cb8313',1,'stack.c']]]
];
