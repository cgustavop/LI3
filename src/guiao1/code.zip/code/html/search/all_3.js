var searchData=
[
  ['stack_2ec_10',['stack.c',['../stack_8c.html',1,'']]],
  ['stack_5fempty_11',['STACK_EMPTY',['../stack_8c.html#afceb75332628ecda1b4793a63b70f00c',1,'stack.c']]],
  ['stack_5fsize_12',['STACK_SIZE',['../stack_8c.html#af47e5cb287f1c5734a65d00b47cb8313',1,'stack.c']]]
];
