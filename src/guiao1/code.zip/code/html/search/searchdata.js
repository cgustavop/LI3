var indexSectionsWithContent =
{
  0: "empst",
  1: "mps",
  2: "mps",
  3: "mt",
  4: "es"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros"
};

