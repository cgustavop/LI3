var searchData=
[
  ['stack_5fempty_27',['STACK_EMPTY',['../stack_8c.html#afceb75332628ecda1b4793a63b70f00c',1,'stack.c']]]
];
