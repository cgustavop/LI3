var searchData=
[
  ['stack_2ec_17',['stack.c',['../stack_8c.html',1,'']]]
];
