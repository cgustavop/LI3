var searchData=
[
  ['size_36',['size',['../classStack.html#a481e5f6b9dd188a3c908d358678847e3',1,'Stack']]],
  ['stack_37',['Stack',['../classStack.html#a3dda891eaa1e7650043e9d9596406164',1,'Stack']]]
];
