var searchData=
[
  ['empty_0',['EMPTY',['../stack_8c.html#a2b7cf2a3641be7b89138615764d60ba3',1,'stack.c']]]
];
