var searchData=
[
  ['operator_3c_3c_29',['operator&lt;&lt;',['../stack_8h.html#ab1962866e487c84b8e76de9ff0e9ca4a',1,'stack.h']]],
  ['operator_3e_3e_30',['operator&gt;&gt;',['../stack_8h.html#a6aa29804db7f548efb6793bdc3f6da0d',1,'stack.h']]]
];
